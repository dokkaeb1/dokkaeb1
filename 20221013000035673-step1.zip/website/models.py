from flask_login import UserMixin
from . import db


class User(UserMixin, db.Model):
    def get_id(self):
        return self.email_id

    __tablename__ = 'user'
    user_name = db.Column(db.Text)
    email_id = db.Column(db.Text, primary_key=True)
    password_hash = db.Column(db.Text)
    phone = db.Column(db.Text)
    address = db.Column(db.Text)
