from werkzeug.security import generate_password_hash
from . import db
from . import models


def init_database(app):
    with app.app_context():
        db.drop_all()
        db.create_all()

        db.session.add(models.User(
            email_id="123@123.com",
            password_hash=generate_password_hash("123", method='sha256'),
            user_name="test user",
            phone="12345678",
            address="USA"
        ))

        db.session.commit()
